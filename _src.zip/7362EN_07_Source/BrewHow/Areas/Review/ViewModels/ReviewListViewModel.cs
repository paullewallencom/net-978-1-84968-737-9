﻿using System;

namespace BrewHow.Areas.Review.ViewModels
{
    public class ReviewListViewModel
    {
        public int Rating { get; set; }
        public string Comment { get; set; }
    }
}