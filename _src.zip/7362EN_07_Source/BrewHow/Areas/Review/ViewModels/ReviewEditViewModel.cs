﻿using System;

namespace BrewHow.Areas.Review.ViewModels
{
    public class ReviewEditViewModel
    {
        public int Rating { get; set; }
        public string Comment { get; set; }
    }
}