﻿using System;

namespace BrewHow.Domain.Entities
{
    public enum CategoryEntity
    {
        Ale,
        Lager
    }
}