﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BrewHow.ViewModels
{
    public class StyleDisplayViewModel
    {
        public int StyleId { get; set; }
        public string Category { get; set; }
        public string Name { get; set; }
    }
}