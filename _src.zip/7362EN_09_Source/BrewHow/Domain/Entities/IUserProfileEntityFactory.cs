﻿using System;

namespace BrewHow.Domain.Entities
{
    public interface IUserProfileEntityFactory
    {
        UserProfileEntity Create();
    }
}
