﻿using System;

namespace BrewHow.Domain.Entities
{
    public class UserProfileEntity
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }
}