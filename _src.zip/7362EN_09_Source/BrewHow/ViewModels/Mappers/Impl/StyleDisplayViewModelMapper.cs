﻿using System;

using BrewHow.Domain.Entities;

namespace BrewHow.ViewModels.Mappers.Impl
{
    public class StyleDisplayViewModelMapper 
        : IStyleDisplayViewModelMapper
    {
        public StyleDisplayViewModelMapper()
        {
        }

        public StyleEntity ViewModelToEntity(StyleDisplayViewModel viewModel)
        {
            throw new NotImplementedException();
        }

        public StyleDisplayViewModel EntityToViewModel(StyleEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}